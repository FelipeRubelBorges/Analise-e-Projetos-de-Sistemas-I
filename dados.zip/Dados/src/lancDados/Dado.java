package lancDados;
public class Dado {

	private int lados1;
	private int lados2;
	private int resultado; 
	
	public int getLados1() {
		return lados1;
	}

	public void setLados1(int lados1) {
		this.lados1 = lados1;
	}

	public int getLados2() {
		return lados2;
	}

	public void setLados2(int lados2) {
		this.lados2 = lados2;
	}

	public int lancarDado1() {
		resultado = (int) (Math.random()*lados1 + 1);
		
		return resultado;
	}
	
	public int lancarDado2() {
		resultado = (int) (Math.random()*lados2 + 1);
		
		return resultado;
	}
	
}

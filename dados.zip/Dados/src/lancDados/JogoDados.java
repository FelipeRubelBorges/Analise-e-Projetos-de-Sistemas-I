package lancDados;

public class JogoDados {

	public static void main(String[] args) {
		
		Dado dado = new Dado();
		
		dado.setLados1(6);
		dado.setLados2(6);
		
		System.out.println("Lan�amento do DADO.................");
		
		int nroDado1 = dado.lancarDado1();
		int nroDado2 = dado.lancarDado1();
		int soma = nroDado1+nroDado2;
		System.out.println("Resultado Dado 1: " + nroDado1);
		System.out.println("Resultado Dado 2: " + nroDado2);
		if (soma == 7) {
			System.out.println("A soma dos DADOS foi: " + soma + "   VOC� GANHOU!!!!");
		} else {
			System.out.println("A soma dos DADOS foi: " + soma + "   VOC� PERDEU!!!!");
		}
	}
}
package lancDados;

import static org.junit.Assert.*;

import org.junit.Test;

public class DadoTest {

	@Test
	public void testGetLados1() {
		System.out.println("GetLado1");
		
		int lado = 1;
		Dado instance = new Dado();
		instance.setLados1(lado);
		assertEquals(lado, instance.getLados1(),0);
	}

	@Test
	public void testSetLados1() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLados2() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetLados2() {
		fail("Not yet implemented");
	}

	@Test
	public void testLancarDado1() {
		
		fail("Not yet implemented");
	}

	@Test
	public void testLancarDado2() {
		fail("Not yet implemented");
	}

}
